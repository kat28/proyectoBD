﻿namespace ProyectoFinalG3
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.tabMenu = new System.Windows.Forms.TabControl();
            this.tabBD = new System.Windows.Forms.TabPage();
            this.chboxBD = new System.Windows.Forms.CheckedListBox();
            this.picCrearBD = new System.Windows.Forms.PictureBox();
            this.txtNuevaBD = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tabUsuario = new System.Windows.Forms.TabPage();
            this.tabSQL = new System.Windows.Forms.TabPage();
            this.picGuardar = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.chboxColumna = new System.Windows.Forms.CheckedListBox();
            this.txtConsulta = new System.Windows.Forms.RichTextBox();
            this.picEjecutar = new System.Windows.Forms.PictureBox();
            this.picBorrar = new System.Windows.Forms.PictureBox();
            this.picAnalizar = new System.Windows.Forms.PictureBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelTituloSQL = new System.Windows.Forms.Label();
            this.imageList32 = new System.Windows.Forms.ImageList(this.components);
            this.headerPanel = new System.Windows.Forms.Panel();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.LogoPanel = new System.Windows.Forms.Panel();
            this.LogoTitulo = new System.Windows.Forms.Label();
            this.treeViewBD = new System.Windows.Forms.TreeView();
            this.sidePanel = new System.Windows.Forms.Panel();
            this.bottom1Panel = new System.Windows.Forms.Panel();
            this.imageList16 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.bottom2Panel = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabMenu.SuspendLayout();
            this.tabBD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCrearBD)).BeginInit();
            this.tabSQL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGuardar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEjecutar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAnalizar)).BeginInit();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            this.LogoPanel.SuspendLayout();
            this.sidePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMenu
            // 
            this.tabMenu.AccessibleDescription = "";
            this.tabMenu.Controls.Add(this.tabBD);
            this.tabMenu.Controls.Add(this.tabUsuario);
            this.tabMenu.Controls.Add(this.tabSQL);
            this.tabMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMenu.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMenu.ImageList = this.imageList32;
            this.tabMenu.Location = new System.Drawing.Point(225, 41);
            this.tabMenu.Name = "tabMenu";
            this.tabMenu.SelectedIndex = 0;
            this.tabMenu.Size = new System.Drawing.Size(718, 391);
            this.tabMenu.TabIndex = 2;
            // 
            // tabBD
            // 
            this.tabBD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(249)))));
            this.tabBD.Controls.Add(this.chboxBD);
            this.tabBD.Controls.Add(this.picCrearBD);
            this.tabBD.Controls.Add(this.txtNuevaBD);
            this.tabBD.Controls.Add(this.label2);
            this.tabBD.Controls.Add(this.button1);
            this.tabBD.ImageIndex = 1;
            this.tabBD.Location = new System.Drawing.Point(4, 39);
            this.tabBD.Name = "tabBD";
            this.tabBD.Padding = new System.Windows.Forms.Padding(3);
            this.tabBD.Size = new System.Drawing.Size(710, 348);
            this.tabBD.TabIndex = 0;
            this.tabBD.Text = "Bases de Datos";
            // 
            // chboxBD
            // 
            this.chboxBD.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chboxBD.FormattingEnabled = true;
            this.chboxBD.Location = new System.Drawing.Point(25, 165);
            this.chboxBD.Name = "chboxBD";
            this.chboxBD.Size = new System.Drawing.Size(263, 109);
            this.chboxBD.TabIndex = 11;
            // 
            // picCrearBD
            // 
            this.picCrearBD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picCrearBD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picCrearBD.Image = ((System.Drawing.Image)(resources.GetObject("picCrearBD.Image")));
            this.picCrearBD.Location = new System.Drawing.Point(198, 72);
            this.picCrearBD.Name = "picCrearBD";
            this.picCrearBD.Size = new System.Drawing.Size(43, 40);
            this.picCrearBD.TabIndex = 10;
            this.picCrearBD.TabStop = false;
            this.toolTip1.SetToolTip(this.picCrearBD, "Crear BD");
            this.picCrearBD.Click += new System.EventHandler(this.picCrearBD_Click);
            // 
            // txtNuevaBD
            // 
            this.txtNuevaBD.Location = new System.Drawing.Point(25, 79);
            this.txtNuevaBD.Name = "txtNuevaBD";
            this.txtNuevaBD.Size = new System.Drawing.Size(155, 26);
            this.txtNuevaBD.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label2.Location = new System.Drawing.Point(21, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Bases de Datos";
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(495, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 70);
            this.button1.TabIndex = 0;
            this.button1.Text = "boton de pruebas";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabUsuario
            // 
            this.tabUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(249)))));
            this.tabUsuario.ImageIndex = 5;
            this.tabUsuario.Location = new System.Drawing.Point(4, 39);
            this.tabUsuario.Name = "tabUsuario";
            this.tabUsuario.Size = new System.Drawing.Size(710, 348);
            this.tabUsuario.TabIndex = 2;
            this.tabUsuario.Text = "Usuarios";
            // 
            // tabSQL
            // 
            this.tabSQL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(249)))));
            this.tabSQL.Controls.Add(this.label3);
            this.tabSQL.Controls.Add(this.comboBox1);
            this.tabSQL.Controls.Add(this.picGuardar);
            this.tabSQL.Controls.Add(this.richTextBox1);
            this.tabSQL.Controls.Add(this.chboxColumna);
            this.tabSQL.Controls.Add(this.txtConsulta);
            this.tabSQL.Controls.Add(this.picEjecutar);
            this.tabSQL.Controls.Add(this.picBorrar);
            this.tabSQL.Controls.Add(this.picAnalizar);
            this.tabSQL.Controls.Add(this.btnDelete);
            this.tabSQL.Controls.Add(this.btnUpdate);
            this.tabSQL.Controls.Add(this.btnInsert);
            this.tabSQL.Controls.Add(this.btnSelect);
            this.tabSQL.Controls.Add(this.label1);
            this.tabSQL.Controls.Add(this.labelTituloSQL);
            this.tabSQL.ImageIndex = 2;
            this.tabSQL.Location = new System.Drawing.Point(4, 39);
            this.tabSQL.Name = "tabSQL";
            this.tabSQL.Padding = new System.Windows.Forms.Padding(3);
            this.tabSQL.Size = new System.Drawing.Size(710, 348);
            this.tabSQL.TabIndex = 1;
            this.tabSQL.Text = "Editor SQL";
            // 
            // picGuardar
            // 
            this.picGuardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picGuardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picGuardar.Image = global::ProyectoFinalG3.Properties.Resources.guardar1;
            this.picGuardar.Location = new System.Drawing.Point(369, 9);
            this.picGuardar.Name = "picGuardar";
            this.picGuardar.Size = new System.Drawing.Size(35, 40);
            this.picGuardar.TabIndex = 15;
            this.picGuardar.TabStop = false;
            this.toolTip1.SetToolTip(this.picGuardar, "Ejecutar Consulta");
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(10, 229);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(517, 82);
            this.richTextBox1.TabIndex = 14;
            this.richTextBox1.Text = "";
            // 
            // chboxColumna
            // 
            this.chboxColumna.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chboxColumna.FormattingEnabled = true;
            this.chboxColumna.Location = new System.Drawing.Point(551, 55);
            this.chboxColumna.Name = "chboxColumna";
            this.chboxColumna.Size = new System.Drawing.Size(151, 256);
            this.chboxColumna.TabIndex = 13;
            // 
            // txtConsulta
            // 
            this.txtConsulta.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsulta.Location = new System.Drawing.Point(10, 55);
            this.txtConsulta.Name = "txtConsulta";
            this.txtConsulta.Size = new System.Drawing.Size(517, 135);
            this.txtConsulta.TabIndex = 12;
            this.txtConsulta.Text = "";
            // 
            // picEjecutar
            // 
            this.picEjecutar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picEjecutar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picEjecutar.Image = ((System.Drawing.Image)(resources.GetObject("picEjecutar.Image")));
            this.picEjecutar.Location = new System.Drawing.Point(410, 9);
            this.picEjecutar.Name = "picEjecutar";
            this.picEjecutar.Size = new System.Drawing.Size(35, 40);
            this.picEjecutar.TabIndex = 11;
            this.picEjecutar.TabStop = false;
            this.toolTip1.SetToolTip(this.picEjecutar, "Ejecutar Consulta");
            this.picEjecutar.Click += new System.EventHandler(this.picEjecutar_Click);
            // 
            // picBorrar
            // 
            this.picBorrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picBorrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBorrar.Image = ((System.Drawing.Image)(resources.GetObject("picBorrar.Image")));
            this.picBorrar.Location = new System.Drawing.Point(492, 9);
            this.picBorrar.Name = "picBorrar";
            this.picBorrar.Size = new System.Drawing.Size(35, 40);
            this.picBorrar.TabIndex = 10;
            this.picBorrar.TabStop = false;
            this.toolTip1.SetToolTip(this.picBorrar, "Borrar Consulta");
            this.picBorrar.Click += new System.EventHandler(this.picBorrar_Click);
            // 
            // picAnalizar
            // 
            this.picAnalizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picAnalizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAnalizar.Image = ((System.Drawing.Image)(resources.GetObject("picAnalizar.Image")));
            this.picAnalizar.Location = new System.Drawing.Point(451, 9);
            this.picAnalizar.Name = "picAnalizar";
            this.picAnalizar.Size = new System.Drawing.Size(35, 40);
            this.picAnalizar.TabIndex = 9;
            this.picAnalizar.TabStop = false;
            this.toolTip1.SetToolTip(this.picAnalizar, "Analizar");
            this.picAnalizar.Click += new System.EventHandler(this.picAnalizar_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(172, 196);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 27);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.White;
            this.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(10, 196);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 27);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.BackColor = System.Drawing.Color.White;
            this.btnInsert.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnInsert.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnInsert.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInsert.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Location = new System.Drawing.Point(91, 196);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(75, 27);
            this.btnInsert.TabIndex = 5;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.White;
            this.btnSelect.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnSelect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSelect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(253, 196);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 27);
            this.btnSelect.TabIndex = 4;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label1.Location = new System.Drawing.Point(570, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Columnas";
            // 
            // labelTituloSQL
            // 
            this.labelTituloSQL.AutoSize = true;
            this.labelTituloSQL.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTituloSQL.ForeColor = System.Drawing.SystemColors.MenuText;
            this.labelTituloSQL.Location = new System.Drawing.Point(6, 20);
            this.labelTituloSQL.Name = "labelTituloSQL";
            this.labelTituloSQL.Size = new System.Drawing.Size(267, 22);
            this.labelTituloSQL.TabIndex = 1;
            this.labelTituloSQL.Text = "Ejecuta las consultas de SQL";
            // 
            // imageList32
            // 
            this.imageList32.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList32.ImageStream")));
            this.imageList32.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList32.Images.SetKeyName(0, "addDatabase.png");
            this.imageList32.Images.SetKeyName(1, "database.png");
            this.imageList32.Images.SetKeyName(2, "draw.png");
            this.imageList32.Images.SetKeyName(3, "execute.png");
            this.imageList32.Images.SetKeyName(4, "query.png");
            this.imageList32.Images.SetKeyName(5, "team.png");
            this.imageList32.Images.SetKeyName(6, "exit.png");
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.White;
            this.headerPanel.Controls.Add(this.picExit);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(225, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(718, 41);
            this.headerPanel.TabIndex = 1;
            // 
            // picExit
            // 
            this.picExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExit.Image = ((System.Drawing.Image)(resources.GetObject("picExit.Image")));
            this.picExit.Location = new System.Drawing.Point(674, 3);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(32, 32);
            this.picExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picExit.TabIndex = 0;
            this.picExit.TabStop = false;
            this.toolTip1.SetToolTip(this.picExit, "Salir");
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // LogoPanel
            // 
            this.LogoPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.LogoPanel.Controls.Add(this.LogoTitulo);
            this.LogoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogoPanel.Location = new System.Drawing.Point(0, 0);
            this.LogoPanel.Name = "LogoPanel";
            this.LogoPanel.Size = new System.Drawing.Size(225, 61);
            this.LogoPanel.TabIndex = 2;
            // 
            // LogoTitulo
            // 
            this.LogoTitulo.AutoSize = true;
            this.LogoTitulo.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoTitulo.ForeColor = System.Drawing.SystemColors.Window;
            this.LogoTitulo.Location = new System.Drawing.Point(6, 18);
            this.LogoTitulo.Name = "LogoTitulo";
            this.LogoTitulo.Size = new System.Drawing.Size(180, 23);
            this.LogoTitulo.TabIndex = 0;
            this.LogoTitulo.Text = "Proyecto Final BD2";
            // 
            // treeViewBD
            // 
            this.treeViewBD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.treeViewBD.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeViewBD.ForeColor = System.Drawing.SystemColors.Info;
            this.treeViewBD.Location = new System.Drawing.Point(0, 61);
            this.treeViewBD.Name = "treeViewBD";
            this.treeViewBD.Size = new System.Drawing.Size(222, 350);
            this.treeViewBD.TabIndex = 3;
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(196)))), ((int)(((byte)(37)))));
            this.sidePanel.Controls.Add(this.bottom1Panel);
            this.sidePanel.Controls.Add(this.treeViewBD);
            this.sidePanel.Controls.Add(this.LogoPanel);
            this.sidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidePanel.Location = new System.Drawing.Point(0, 0);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(225, 432);
            this.sidePanel.TabIndex = 0;
            // 
            // bottom1Panel
            // 
            this.bottom1Panel.BackColor = System.Drawing.Color.Gainsboro;
            this.bottom1Panel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottom1Panel.Location = new System.Drawing.Point(0, 411);
            this.bottom1Panel.Name = "bottom1Panel";
            this.bottom1Panel.Size = new System.Drawing.Size(225, 21);
            this.bottom1Panel.TabIndex = 2;
            // 
            // imageList16
            // 
            this.imageList16.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList16.ImageStream")));
            this.imageList16.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList16.Images.SetKeyName(0, "addDatabase.png");
            this.imageList16.Images.SetKeyName(1, "databas.png");
            this.imageList16.Images.SetKeyName(2, "database.png");
            this.imageList16.Images.SetKeyName(3, "databaseGrey.png");
            this.imageList16.Images.SetKeyName(4, "datagrey.png");
            this.imageList16.Images.SetKeyName(5, "datawhite.png");
            this.imageList16.Images.SetKeyName(6, "dbgrey.png");
            this.imageList16.Images.SetKeyName(7, "dbwhite.png");
            this.imageList16.Images.SetKeyName(8, "draw.png");
            this.imageList16.Images.SetKeyName(9, "execute.png");
            this.imageList16.Images.SetKeyName(10, "exit.png");
            this.imageList16.Images.SetKeyName(11, "query.png");
            this.imageList16.Images.SetKeyName(12, "team.png");
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 100;
            // 
            // bottom2Panel
            // 
            this.bottom2Panel.BackColor = System.Drawing.Color.Gainsboro;
            this.bottom2Panel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottom2Panel.Location = new System.Drawing.Point(225, 411);
            this.bottom2Panel.Name = "bottom2Panel";
            this.bottom2Panel.Size = new System.Drawing.Size(718, 21);
            this.bottom2Panel.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(406, 197);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 26);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label3.Location = new System.Drawing.Point(360, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "BD:";
           // this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(943, 432);
            this.Controls.Add(this.bottom2Panel);
            this.Controls.Add(this.tabMenu);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.sidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "home";
            this.Text = "home";
            this.tabMenu.ResumeLayout(false);
            this.tabBD.ResumeLayout(false);
            this.tabBD.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCrearBD)).EndInit();
            this.tabSQL.ResumeLayout(false);
            this.tabSQL.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGuardar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEjecutar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAnalizar)).EndInit();
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            this.LogoPanel.ResumeLayout(false);
            this.LogoPanel.PerformLayout();
            this.sidePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabMenu;
        private System.Windows.Forms.TabPage tabBD;
        private System.Windows.Forms.TabPage tabSQL;
        private System.Windows.Forms.TabPage tabUsuario;
        private System.Windows.Forms.ImageList imageList32;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel LogoPanel;
        private System.Windows.Forms.Label LogoTitulo;
        private System.Windows.Forms.TreeView treeViewBD;
        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Label labelTituloSQL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.ImageList imageList16;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox picAnalizar;
        private System.Windows.Forms.PictureBox picBorrar;
        private System.Windows.Forms.PictureBox picEjecutar;
        private System.Windows.Forms.Panel bottom2Panel;
        private System.Windows.Forms.Panel bottom1Panel;
        private System.Windows.Forms.PictureBox picCrearBD;
        private System.Windows.Forms.TextBox txtNuevaBD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckedListBox chboxBD;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox txtConsulta;
        private System.Windows.Forms.CheckedListBox chboxColumna;
        private System.Windows.Forms.PictureBox picGuardar;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
    }
}